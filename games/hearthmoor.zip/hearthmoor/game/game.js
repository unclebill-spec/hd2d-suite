// Hearthmoor: a cozy HD-2D action RPG on the hd2d runtime (engine/main.js boot + hooks).
// Area manager (fresh canvas per area, fade), hero picker (6 starters), real-time combat (combat.js), dialogue,
// 3 errands + quest log, bag, persistent clock, 4 spell slots, save/load (localStorage hearthmoor-slot-1-v2, migrates
// v1), ambient audio, PWA install + fullscreen + display presets.
import { boot, DISPLAY_PRESETS, getDisplay, setDisplay } from '../engine/main.js';
import { ITEMS, QUESTS, TALK, SPELL_NAMES, markerFor } from './data.js';
import { Ambient } from './audio.js';
import * as PR from './progress.js';
import { HEROES, HERO, SPELLS, SUMMONS } from './heroes.js';
import { Combat } from './combat.js';

// PWA install: catch the browser's prompt as early as possible (Chrome / Edge / Android); iPhone gets a tip instead
let installEvt = null;
addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installEvt = e; syncInstall(); });
addEventListener('appinstalled', () => { installEvt = null; syncInstall(); });

const Q = new URLSearchParams(location.search);
const SLOT_V2 = 'hearthmoor-slot-1-v2';
const SLOT_V1 = 'hearthmoor-slot-1-v1';       // read once for migration, never written or deleted
const QA = Q.has('qa');                       // check-scene / screenshots: straight into ?area=, fresh state, no title, no saving
const AREAS = { plaza: 'areas/plaza/', lane: 'areas/lane/', mossglen: 'areas/mossglen/' };
const DAY_SECONDS = Number(Q.get('day') || 720);  // one whole day = 12 real minutes (day, dusk, night, dawn)
const $ = (id) => document.getElementById(id);

// v2 adds the hero class (cls) and current HP; everything from v1 carries over unchanged
const fresh = () => ({ v: 2, cls: null, hp: null, area: 'plaza', pos: null, t: 0.62, inv: {}, quests: { bread: 0, tea: 0, cat: 0 }, picked: {},
                       cat: 'glade', spells: ['sparkle_burst'], played: 0, savedAt: null });

const G = {
  S: fresh(), game: null, ctx: null, busy: false, title: !QA, dlg: null, log: false, markers: {}, scenes: {}, armed: false,
  audio: new Ambient(), autosave: 20, near: null, downed: false, opts: false, picking: false,
  peace: Q.has('peace') || (QA && !Q.has('combat')),
  qaStill: QA && !Q.has('combat'),   // QA screenshots / check-scene: enemies stand around unless &combat
};
G.combat = new Combat(G);
window.__hm = G;   // smoke tests + debugging

// ------------------------------------------------------------------ save / load
function readSave() {
  try { const s = JSON.parse(localStorage.getItem(SLOT_V2)); if (s && s.v === 2) return s; } catch (e) { /* corrupt: fall through */ }
  try {   // migrate a v1 save: same fields, no class yet (Continue asks who you are, then carries on)
    const o = JSON.parse(localStorage.getItem(SLOT_V1));
    if (o && o.v === 1) return { ...fresh(), ...o, v: 2, cls: null, hp: null, migrated: 1 };
  } catch (e) { /* ignore */ }
  return null;
}
// the 4 spell slots: the hero's own spell first, then the newest three charms
function slots() { const h = HERO[G.S.cls]; return [...(h ? [h.spell] : []), ...G.S.spells.slice(-3)].slice(0, 4); }
G.slots = slots;
function save(note) {
  if (QA || G.title) return false;
  const p = G.ctx && G.ctx.player;
  if (p) G.S.pos = [+p.x.toFixed(2), +p.z.toFixed(2), p.facing];
  G.S.area = G.area; G.S.savedAt = new Date().toISOString();
  localStorage.setItem(SLOT_V2, JSON.stringify(G.S));
  if (note) { toast('Saved ✓'); G.audio.sfx('save'); }
  return true;
}
G.save = save; G.readSave = readSave;

// ------------------------------------------------------------------ inventory + quests (used by data.js)
G.give = (id, n = 1) => { G.S.inv[id] = (G.S.inv[id] || 0) + n; drawBag(id); toast(`+${n} ${ITEMS[id].name}`); };
G.take = (id, n = 1) => { G.S.inv[id] = Math.max(0, (G.S.inv[id] || 0) - n); if (!G.S.inv[id]) delete G.S.inv[id]; drawBag(); };
G.setQuest = (id, stage) => {
  const was = G.S.quests[id]; G.S.quests[id] = stage; drawLog();
  if (stage === 3 && was !== 3) { toast(`Errand done: ${QUESTS[id].title}`, 2.6); G.audio.sfx('quest'); G.gainXP(PR.XP.errand); }
  else if (was === 0 && stage > 0) { toast(`New errand: ${QUESTS[id].title}`, 2.6); G.audio.sfx('pickup'); flashLog(); }
  refreshMarkers(); save();
};
G.learn = (spell) => {
  if (G.S.spells.includes(spell)) return;
  G.S.spells.push(spell);
  if (G.ctx) G.ctx.setSpellCycle(slots());
  toast(`Learned a charm: ${SPELL_NAMES[spell] || spell} (F to cast, Q to switch)`, 3.2);
};
G.catFollow = () => {
  G.S.cat = 'follow';
  const a = G.ctx.npc('cat'); if (a) { a.behavior = 'follow'; a.speed = 2.4; }
};
G.catHome = () => {
  G.S.cat = 'home';
  const a = G.ctx && G.ctx.npc('cat');
  if (a) { a.behavior = 'wander'; a.home = [4.8, 3.4]; a.radius = 1.4; a.speed = 1.4; a.target = null; a.wait = 2; }
};

// ------------------------------------------------------------------ HUD: bag, quest log, toast, prompt
const ICON = 32;   // 16 px icons drawn at 2x
function iconHTML(id) { const i = ITEMS[id].icon; return `<span class="ico" style="background-position:-${i * ICON}px 0"></span>`; }
function drawBag(flash) {
  const el = $('bag'); if (!el) return;
  const ids = Object.keys(ITEMS).filter((k) => G.S.inv[k]);
  el.innerHTML = ids.length ? ids.map((k) => `<span class="slot${k === flash ? ' new' : ''}" title="${ITEMS[k].name}: ${ITEMS[k].about}">${iconHTML(k)}<b>${G.S.inv[k]}</b></span>`).join('')
                            : '<span class="empty">bag: empty</span>';
  const rail = $('rail');
  if (rail) rail.innerHTML = '';   // the bag chip (top left) is the one inventory display; the pad rail stays empty
}
function drawLog() {
  const el = $('logList'); if (!el) return;
  const rows = Object.entries(QUESTS).map(([id, q]) => {
    const st = G.S.quests[id];
    if (!st) return `<li class="todo"><b>${q.title}</b><span>Someone in town may need a hand… (${q.giver})</span></li>`;
    let step = q.steps[st] || '';
    if (id === 'tea' && st === 1) step += ` (${G.S.inv.moonpetal || 0}/3)`;
    return `<li class="${st === 3 ? 'done' : 'active'}"><b>${st === 3 ? '✓ ' : '◆ '}${q.title}</b><span>${step}</span></li>`;
  });
  el.innerHTML = rows.join('');
  const n = Object.values(G.S.quests).filter((v) => v === 3).length;
  $('logCount').textContent = `${n}/3 done`;
  $('btnLog').textContent = `quests ${n}/3`;
  const sp = $('logSpells');
  if (sp) sp.textContent = 'Spell slots: ' + slots().map((s) => spellName(s)).join(' · ') + '  ·  Charms known: ' + G.S.spells.map((s) => SPELL_NAMES[s] || s).join(' · ');
}
function spellName(id) { return (SPELLS[id] && SPELLS[id].name) || SPELL_NAMES[id] || String(id).replace(/_/g, ' '); }
G.spellName = spellName;
function flashLog() { const b = $('btnLog'); b.classList.add('ping'); setTimeout(() => b.classList.remove('ping'), 1600); }
function setLog(open) { G.log = open; $('log').hidden = !open; $('btnLog').classList.toggle('on', open); if (open) drawLog(); }
let toastT = 0;
function toast(msg, s = 2.0) { const el = $('toast'); el.textContent = msg; el.hidden = false; el.classList.remove('out'); toastT = s; }
G.toast = toast;

// ------------------------------------------------------------------ dialogue (carved-wood frame, parchment page)
let portraitImg = null;
function openDialogue(npc, entry) {
  G.dlg = { npc, pages: entry.pages, i: 0, then: entry.then, shown: 0, full: false };
  $('dlgName').textContent = npc.name || npc.role;
  drawPortrait(npc);
  $('dlg').hidden = false; document.body.classList.add('dlgopen');
  G.audio.sfx('blip');
  showPage();
}
function showPage() {
  const d = G.dlg; d.shown = 0; d.full = false;
  $('dlgText').textContent = '';
  $('dlgMore').textContent = d.i < d.pages.length - 1 ? '▼' : '✕';
  $('dlgPage').textContent = `${d.i + 1}/${d.pages.length}`;
}
function advanceDialogue() {
  const d = G.dlg; if (!d) return;
  if (!d.full) { d.shown = 1e9; return; }       // first press finishes the line
  if (d.i < d.pages.length - 1) { d.i++; G.audio.sfx('blip'); showPage(); return; }
  closeDialogue();
}
function closeDialogue() {
  const d = G.dlg; G.dlg = null; $('dlg').hidden = true; document.body.classList.remove('dlgopen');
  if (d && d.then) d.then(G);
}
function typeDialogue(dt) {
  const d = G.dlg; if (!d || d.full) return;
  d.shown += dt * 55;
  const txt = d.pages[d.i];
  const n = Math.min(txt.length, Math.floor(d.shown));
  $('dlgText').textContent = txt.slice(0, n);
  if (n >= txt.length) d.full = true;
}
function drawPortrait(npc) {
  const cv = $('dlgFace'), g = cv.getContext('2d');
  g.imageSmoothingEnabled = false; g.clearRect(0, 0, cv.width, cv.height);
  const r = npc.rect; if (!r || !portraitImg) return;
  const fw = r.w / r.k, fh = r.h / r.k;
  // the idle-down frame of this role row (column 0), cropped to the head and shoulders
  const fy = r.frame[1];
  const sh = Math.min(fh, 22), sy = fy + Math.max(0, fh - 34);
  const s = Math.floor(Math.min(cv.width / fw, cv.height / sh));
  g.drawImage(portraitImg, 0, sy, fw, sh, Math.round((cv.width - fw * s) / 2), cv.height - sh * s, fw * s, sh * s);
}

// ------------------------------------------------------------------ area manager
async function sceneOf(id) {
  if (!G.scenes[id]) G.scenes[id] = await (await fetch(AREAS[id] + 'scene.json')).json();
  return G.scenes[id];
}
async function loadArea(id, spawnKey, pos) {
  const sc = await sceneOf(id);
  const gm = sc.game || {};
  let sp = pos ? { x: pos[0], z: pos[1], facing: pos[2] } : null;
  if (!sp) { const s = (gm.spawns || {})[spawnKey] || (gm.spawns || {}).start; if (s) sp = { x: s[0], z: s[1], facing: s[2] }; }
  if (G.game) { G.game.dispose(); G.game = null; G.ctx = null; }
  G.markers = {};
  const old = $('view'); if (old) old.remove();
  const canvas = document.createElement('canvas'); canvas.id = 'view'; document.body.prepend(canvas);
  G.area = id; G.S.area = id; G.armed = false;
  G.combat.detach();
  G.game = await boot({ base: AREAS[id], canvas, spawn: sp, startT: G.S.t, clockSpeed: 1 / DAY_SECONDS, spellCycle: slots(),
                        player: { role: G.S.cls || G.preview || 'wildcaller' }, castAdvance: false,
                        keepTitle: true, padHandled: true, hooks, toast: (m, t) => toast(m, t) });
  const ctx = G.ctx = G.game.ctx;
  G.combat.attach(ctx, id);
  // portrait source: this area's actor atlas
  portraitImg = new Image(); portraitImg.src = AREAS[id] + ctx.scene.atlas.image;
  // pickups already taken stay gone
  for (const pk of gm.pickups || []) if (G.S.picked[pk.fx] && ctx.fx[pk.fx]) { ctx.gamefx.remove(ctx.fx[pk.fx]); delete ctx.fx[pk.fx]; }
  // Pudding tags along between areas
  if (G.S.cat === 'follow' && !ctx.npc('cat')) {
    ctx.addNpc({ id: 'cat', role: 'cat', name: 'Pudding', pos: [ctx.player.x - 0.7, ctx.player.z + 0.5], behavior: 'follow', speed: 2.4, say: ['Mrrp!'] });
  } else if (G.S.cat === 'follow') { const a = ctx.npc('cat'); a.behavior = 'follow'; a.speed = 2.4; }
  G.audio.setArea(id);
  refreshMarkers();
  drawBag(); drawLog();
  document.title = `Hearthmoor · ${ctx.scene.name}`;
}
G.loadArea = loadArea;

async function go(to, spawnKey, how) {
  if (G.busy) return; G.busy = true;
  const f = $('fade'); f.className = how === 'portal' ? 'portal on' : 'on';
  if (how === 'portal') { G.audio.sfx('portal'); const p = G.ctx.player; G.ctx.effects && G.ctx.effects.spawn('sparkle_burst', p.x, p.y, p.z); }
  await new Promise((r) => setTimeout(r, how === 'portal' ? 620 : 380));
  G.S.pos = null;
  try { await loadArea(to, spawnKey); } catch (e) { console.error(e); }
  save();
  f.className = how === 'portal' ? 'portal' : '';
  await new Promise((r) => setTimeout(r, 360));
  G.busy = false;
  toast(G.ctx.scene.name, 1.6);
}
G.go = go;

// ------------------------------------------------------------------ quest tags over heads
function refreshMarkers() {
  const ctx = G.ctx; if (!ctx || !ctx.gamefx) return;
  for (const a of ctx.actors.list) {
    if (a.id === 'player') continue;
    const want = markerFor(a.id, G.S);
    const have = G.markers[a.id];
    if (have && have.name !== want) { ctx.gamefx.remove(have); delete G.markers[a.id]; }
    if (want && !G.markers[a.id]) G.markers[a.id] = ctx.gamefx.spawn(want, a.x, a.y, a.z, { duration: Infinity });
  }
}
function syncMarkers() {
  for (const [id, f] of Object.entries(G.markers)) { const a = G.ctx.npc(id); if (a) { f.x = a.x; f.y = a.y; f.z = a.z; } }
}

// ------------------------------------------------------------------ per-frame game logic
const inRect = (p, r) => p.x >= r[0] && p.x <= r[2] && p.z >= r[1] && p.z <= r[3];
function nearPickup(ctx, d = 0.85) {
  for (const pk of ctx.scene.game?.pickups || []) {
    const f = ctx.fx[pk.fx]; if (!f || G.S.picked[pk.fx]) continue;
    if (Math.hypot(f.x - ctx.player.x, f.z - ctx.player.z) < d) return pk;
  }
  return null;
}
function pick(ctx, pk) {
  const f = ctx.fx[pk.fx];
  G.S.picked[pk.fx] = true;
  ctx.gamefx.remove(f); delete ctx.fx[pk.fx];
  ctx.effects && ctx.effects.spawn('sparkle_burst', f.x, f.y, f.z);
  G.give(pk.item, 1);
  G.audio.sfx('pickup');
  if (G.S.quests.tea === 1 && (G.S.inv.moonpetal || 0) >= 3) G.setQuest('tea', 2); else { drawLog(); save(); }
}
function onFrame(dt, ctx) {
  const p = ctx.player, gm = ctx.scene.game || {};
  G.S.t = ctx.clock.t;
  G.S.played += dt;
  typeDialogue(dt);
  if (toastT > 0) { toastT -= dt; const el = $('toast'); if (toastT <= 0.35) el.classList.add('out'); if (toastT <= 0) { el.hidden = true; el.classList.remove('out'); } }
  syncMarkers();
  G.combat.update(dt, ctx);
  drawVitals(ctx);
  if (G.title || G.busy) return;
  // exits + portals: arm once the player has stood outside every trigger (no bounce on arrival)
  const trig = [...(gm.exits || []).map((e) => ({ ...e, how: 'walk' })), ...(gm.portals || []).map((e) => ({ ...e, how: 'portal' }))];
  const inside = trig.find((e) => inRect(p, e.rect));
  if (!inside) G.armed = true;
  else if (G.armed && !G.dlg) { go(inside.to, inside.spawn, inside.how); return; }
  // pickups: walk over a glimmer
  const pk = nearPickup(ctx, 0.7); if (pk) pick(ctx, pk);
  // prompt near a gate or a glimmer
  let prompt = '';
  const close = trig.find((e) => Math.max(e.rect[0] - p.x, p.x - e.rect[2], e.rect[1] - p.z, p.z - e.rect[3]) < 1.6);
  if (close) prompt = close.how === 'portal' ? `step into the swirl: ${close.label}` : close.label;
  const pe = $('prompt'); if (pe.textContent !== prompt) { pe.textContent = prompt; pe.hidden = !prompt; }
  G.audio.setNight(ctx.clock.grade ? (ctx.clock.grade().bugs ?? 0) : 0);
  G.autosave -= dt; if (G.autosave <= 0) { G.autosave = 20; save(); }
}

// ------------------------------------------------------------------ vitals + touch-button cooldowns (cheap DOM writes)
const last = {};
function setTxt(id, v) { if (last[id] !== v) { last[id] = v; const el = $(id); if (el) el.textContent = v; } }
function setW(id, f) { const v = Math.round(Math.max(0, Math.min(1, f)) * 100); if (last[id] !== v) { last[id] = v; const el = $(id); if (el) el.style.width = v + '%'; } }
function setCd(id, sec) { const v = sec > 0.05 ? String(Math.ceil(sec)) : ''; if (last[id] !== v) { last[id] = v; const el = $(id); if (el) { if (v) el.dataset.cd = v; else delete el.dataset.cd; } } }
function drawVitals(ctx) {
  const C = G.combat, hp = G.S.hp ?? C.maxHp(), max = C.maxHp();
  setW('hpFill', hp / max); setW('stFill', C.st / C.maxSt());
  const S = G.S; if (S.lv) { setW('xpFill', S.lv >= PR.LEVEL_CAP ? 1 : S.xp / PR.xpNeed(S.lv)); setTxt('lvTxt', 'Lv' + S.lv); setTxt('ptsTxt', (S.free || S.sp) ? `+${S.free + S.sp}` : ''); }
  setTxt('hpTxt', `${Math.ceil(hp)}`);
  const cur = ctx.spellCycle()[ctx.spellIndex()] || '';
  const cd = SPELLS[cur] ? C.cd.spell : C.cd.charm;
  setTxt('spellTxt', '✦ ' + spellName(cur) + (cd > 0.05 ? ` ${cd.toFixed(1)}` : ''));
  setTxt('padSpellName', (spellName(cur).split(' ')[0] || 'spell').slice(0, 7).toLowerCase());
  setCd('padSpell', cd); setCd('padSummon', C.cd.summon);
  const v = $('vitals'), bag = $('bag');
  if (v && bag) {   // sit just under the bag, whatever its height (icons make it taller than the empty chip)
    const top = bag.offsetTop + bag.offsetHeight + 4;
    if (last.vtop !== top) { last.vtop = top; v.style.top = top + 'px'; }
  }
  if (v) { const low = hp / max < 0.3; if (last.low !== low) { last.low = low; v.classList.toggle('low', low); } }
  const near = $('mainGlyph') && $('mainGlyph').textContent === '💬';
  if (last.talk !== near) { last.talk = near; $('padMain').classList.toggle('talk', near); }
}

const hooks = {
  blockInput: () => !!(G.dlg || G.busy || G.title || G.log || G.downed || G.opts || G.picking || G.heroUI || G.asking),
  rollMods: () => { const M = G.combat.M; return { speed: M.rollSpeed, iframes: M.rollIframes }; },
  onCast: (name) => G.combat.cast(name),
  onSummon: () => G.combat.doSummon(),
  onDodge: () => G.combat.onDodge(),
  onAct: (name) => G.combat.onAct(name),
  skipActor: (spec) => spec.id === 'cat' && ((G.area === 'plaza' && G.S.cat !== 'home') || (G.area === 'mossglen' && G.S.cat !== 'glade')),
  onInteract: (ctx, kind) => {
    if (G.title) return true;
    if (G.dlg) { advanceDialogue(); return true; }
    if (G.log) { setLog(false); return true; }
    if (G.busy) return true;
    return false;
  },
  onTalk: (npc, ctx) => {
    const fn = TALK[npc.id];
    const entry = fn ? fn(G.S) : { pages: (Array.isArray(npc.say) ? npc.say : [npc.say || '…']) };
    openDialogue(npc, entry);
    return true;
  },
  onTap: (hit, ctx) => {
    // tapping a glimmer walks onto it; tapping the swirl walks into the gate
    for (const pk of ctx.scene.game?.pickups || []) {
      const f = ctx.fx[pk.fx]; if (!f) continue;
      if (Math.hypot(f.x - hit.x, f.z - hit.z) < 1.0) { ctx.walkTo(f.x, f.z); return true; }
    }
    for (const po of ctx.scene.game?.portals || []) {
      const f = ctx.fx[po.fx]; if (!f) continue;
      if (Math.abs(f.x - hit.x) < 1.2 && hit.z > f.z - 1.2 && hit.z < f.z + 2.0) { ctx.walkTo(f.x, (po.rect[1] + po.rect[3]) / 2); return true; }
    }
    return false;
  },
  // controller buttons (standard mapping) before the engine defaults: title, dialogue, quest log, Start = log
  onPad: (name, ctx) => {
    if (G.picking) {
      if (name === 'left' || name === 'lb') pickMove(-1); else if (name === 'right' || name === 'rb') pickMove(1);
      else if (name === 'up') pickMove(-3); else if (name === 'down') pickMove(3);
      else if (name === 'a' || name === 'start') pickBegin(); else if (name === 'b') closePicker();
      return true;
    }
    if (G.title) {
      if (name === 'a' || name === 'start') (readSave() ? cont : newGame)();
      else if (name === 'x') newGame();
      return true;
    }
    if (G.asking) { if (name === 'left' || name === 'right' || name === 'up' || name === 'down') askMove(); else if (name === 'a') askPick(ASK.yes); else if (name === 'b') askPick(false); return true; }
    if (G.heroUI) { heroPad(name); return true; }
    if (G.opts) { if (name === 'b' || name === 'start' || name === 'a') setOpts(false); return true; }
    if (G.busy || G.downed) return true;
    if (G.dlg) { if (name === 'a') advanceDialogue(); else if (name === 'b') closeDialogue(); return name !== 'select'; }
    if (G.log) { if (name === 'y' || name === 'rb' || name === 'lb') { setLog(false); setHeroUI(true); return true; } if (name === 'a' || name === 'b' || name === 'start') setLog(false); return name !== 'select'; }
    if (name === 'start') { setLog(true); return true; }
    return false;
  },
  onFrame,
  nearThing: (ctx) => !!nearPickup(ctx, 1.4),
};

// ------------------------------------------------------------------ touch action buttons + slow-time spell wheel
function press(id, down, up) {
  const el = $(id); if (!el) return;
  el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); try { el.setPointerCapture(e.pointerId); } catch (err) { /* synthetic */ } down(e); });
  if (up) for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) el.addEventListener(t, (e) => up(e));
}
const WHEEL = { open: false, x0: 0, y0: 0, sel: -1, timer: null };
function openWheel(x, y) {
  const ctx = G.ctx; if (!ctx || hooks.blockInput()) return;
  WHEEL.open = true; WHEEL.x0 = x; WHEEL.y0 = y; WHEEL.sel = -1;
  const cyc = ctx.spellCycle(), cur = ctx.spellIndex();
  document.querySelectorAll('#wheel .slot').forEach((el, i) => { el.textContent = cyc[i] ? spellName(cyc[i]) : ''; el.classList.toggle('cur', i === cur); el.classList.remove('on'); });
  $('wheel').hidden = false;
  ctx.setTimeScale(0.2);
}
function moveWheel(x, y) {
  if (!WHEEL.open) return;
  const dx = x - WHEEL.x0, dy = y - WHEEL.y0, n = G.ctx.spellCycle().length;
  let sel = -1;
  if (Math.hypot(dx, dy) > 22) sel = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
  if (sel >= n) sel = -1;
  WHEEL.sel = sel;
  document.querySelectorAll('#wheel .slot').forEach((el, i) => el.classList.toggle('on', i === sel));
}
function closeWheel(cast) {
  if (!WHEEL.open) return;
  WHEEL.open = false; $('wheel').hidden = true;
  const ctx = G.ctx; if (!ctx) return;
  ctx.setTimeScale(1);
  if (cast && WHEEL.sel >= 0) { ctx.selectSpell(WHEEL.sel); ctx.playerCast(); }
}
G.wheel = { open: openWheel, move: moveWheel, close: closeWheel, state: () => ({ ...WHEEL, timer: undefined }) };
function wirePad() {
  const C = () => G.ctx;
  press('padGuard', () => { if (C()) { C().act('defend', null, { hold: true }); $('padGuard').classList.add('on'); } },
                    () => { if (C()) C().release('defend'); $('padGuard').classList.remove('on'); });
  press('padJump', () => C() && C().act('jump'));
  press('padDodge', () => C() && C().dodge());
  press('padSummon', () => C() && C().summon());
  const sp = $('padSpell');
  press('padSpell', (e) => {
    clearTimeout(WHEEL.timer);
    const x = e.clientX, y = e.clientY;
    WHEEL.timer = setTimeout(() => { WHEEL.timer = 'fired'; openWheel(x, y); }, 350);
  }, (e) => {
    if (e.type === 'lostpointercapture' && !WHEEL.open && WHEEL.timer === null) return;
    if (WHEEL.timer === 'fired') { WHEEL.timer = null; closeWheel(e.type === 'pointerup'); return; }
    if (WHEEL.timer) { clearTimeout(WHEEL.timer); WHEEL.timer = null; if (e.type === 'pointerup' && C()) C().playerCast(); }
  });
  sp.addEventListener('pointermove', (e) => moveWheel(e.clientX, e.clientY));
  press('pad3rd', () => setLog(!G.log));
}

// ------------------------------------------------------------------ options: display presets, fullscreen, install
const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = () => matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: fullscreen)').matches || navigator.standalone === true;
const canFull = () => !!(document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen) && !isIOS;
function syncInstall() {
  const show = !standalone();
  for (const id of ['btnInstall', 'btnInstallT']) { const b = $(id); if (b) b.hidden = !show; }
}
function doInstall(tipId) {
  const tip = $(tipId);
  if (installEvt) { installEvt.prompt(); installEvt.userChoice.finally(() => { installEvt = null; syncInstall(); }); return; }
  const msg = isIOS ? 'iPhone / iPad: tap the Share button (□↑) in Safari, then "Add to Home Screen". Hearthmoor then opens full screen and works offline.'
                    : 'Use your browser menu: "Install app" or "Add to Home screen". Hearthmoor then works offline.';
  if (tip) { tip.textContent = msg; tip.hidden = false; }
}
function toggleFull() {
  const d = document, el = d.documentElement;
  if (d.fullscreenElement || d.webkitFullscreenElement) { (d.exitFullscreen || d.webkitExitFullscreen).call(d); return; }
  const p = (el.requestFullscreen || el.webkitRequestFullscreen).call(el, { navigationUI: 'hide' });
  if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* not supported */ } }).catch(() => {});
}
function syncDisplay() {
  const p = getDisplay();
  document.querySelectorAll('#displayRow [data-p]').forEach((b) => b.classList.toggle('on', b.dataset.p === p));
  const t = $('btnDisplayT'); if (t) t.textContent = 'Display: ' + DISPLAY_PRESETS[p].label;
}
function setOpts(open) {
  G.opts = open; $('opts').hidden = !open; $('btnOpts').classList.toggle('on', open); syncAutoBtn();
  if (open) { syncDisplay(); syncInstall(); $('btnFull').hidden = !canFull(); }
}
G.setOpts = setOpts;
function wireOptions() {
  $('btnOpts').onclick = () => setOpts(!G.opts);
  $('optsClose').onclick = () => setOpts(false);
  $('opts').addEventListener('pointerdown', (e) => { if (e.target === $('opts')) setOpts(false); });
  document.querySelectorAll('#displayRow [data-p]').forEach((b) => { b.onclick = () => { setDisplay(b.dataset.p); syncDisplay(); }; });
  const order = Object.keys(DISPLAY_PRESETS);
  $('btnDisplayT').onclick = () => { setDisplay(order[(order.indexOf(getDisplay()) + 1) % order.length]); syncDisplay(); };
  $('btnFull').onclick = toggleFull; $('btnFullT').onclick = toggleFull;
  $('btnFullT').hidden = !canFull();
  $('btnInstall').onclick = () => doInstall('installTip'); $('btnInstallT').onclick = () => doInstall('installTipT');
  syncInstall(); syncDisplay();
  // rotate prompt: portrait phones only, dismissible, never blocks play (hidden for QA captures)
  const portrait = matchMedia('(orientation: portrait) and (pointer: coarse)');
  let dismissed = false;
  const rot = () => { const show = portrait.matches && !dismissed && !QA && !Q.has('norotate'); $('rotate').hidden = !show; };
  $('rotateX').onclick = () => { dismissed = true; rot(); };
  $('rotate').addEventListener('pointerdown', (e) => { e.stopPropagation(); });
  portrait.addEventListener ? portrait.addEventListener('change', rot) : portrait.addListener(rot);
  rot();
  setTimeout(() => { dismissed = true; rot(); }, 9000);
}

// ------------------------------------------------------------------ hero picker (title -> New game, or a v1 save on Continue)
const PICK = { i: 0, meta: null, img: null, raf: 0, then: null, t0: 0 };
async function heroAtlas() {
  if (PICK.meta) return;
  const base = AREAS.plaza + 'public/art/sprite/';
  PICK.meta = await (await fetch(base + 'actors.json')).json();
  PICK.img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = base + 'actors.png'; });
}
function buildCards() {
  const wrap = $('cards'); wrap.innerHTML = '';
  HEROES.forEach((h, i) => {
    const b = document.createElement('button');
    b.className = 'card'; b.dataset.i = i; b.id = 'hero_' + h.id;
    b.innerHTML = `<canvas width="20" height="32"></canvas><b>${h.cls}</b><i>${h.kind}</i>`;
    b.onclick = () => { if (PICK.i === i && PICK.tapped) pickBegin(); else { PICK.i = i; PICK.tapped = true; pickShow(); } };
    wrap.appendChild(b);
  });
}
function pickShow() {
  const h = HEROES[PICK.i];
  document.querySelectorAll('#cards .card').forEach((c, i) => c.classList.toggle('sel', i === PICK.i));
  $('heroDetail').innerHTML = `<b>${h.cls}</b> <span class="tag">${h.origin}</span><span class="tag ${h.kind}">${h.kind}</span><span class="tag">${h.style}</span><br>${h.blurb}`
    + `<span class="kit">First spell: ${SPELLS[h.spell].name} · Summon: ${SUMMONS[h.summon].name} · ${h.hp} HP</span>`;
  G.preview = h.id;
  if (G.ctx && G.ctx.actors.meta.roles[h.id]) { G.ctx.actors.setRole(G.ctx.player, h.id); G.ctx.actors.act(G.ctx.player, 'attack'); }
  PICK.t0 = performance.now();
}
function drawPreviews(now) {
  if (!G.picking) return;
  const M = PICK.meta, fw = M.frame[0], fh = M.frame[1];
  document.querySelectorAll('#cards .card').forEach((c, i) => {
    const h = HEROES[i], r = M.roles[h.id]; if (!r) return;
    const cv = c.querySelector('canvas'), g = cv.getContext('2d');
    g.imageSmoothingEnabled = false; g.clearRect(0, 0, fw, fh);
    let anim = 'idle', fr = Math.floor(now / 330) % 4;
    if (i === PICK.i) {   // the chosen hero shows off: attack, cast, jump, idle
      const seq = ['attack', 'cast', 'jump', 'idle'], ph = Math.floor((now - PICK.t0) / 900) % 4;
      anim = seq[ph]; if (!r.anims.includes(anim)) anim = 'idle';
      fr = Math.min(3, Math.floor(((now - PICK.t0) % 900) / 180));
    }
    const col = M.anims[anim].start + fr;
    g.drawImage(PICK.img, col * fw, r.row * fh, fw, fh, 0, 0, fw, fh);
  });
  PICK.raf = requestAnimationFrame(drawPreviews);
}
async function openPicker(then) {
  try { await heroAtlas(); } catch (e) { console.error(e); }
  PICK.then = then; PICK.tapped = false;
  const cur = HEROES.findIndex((h) => h.id === (G.S.cls || G.preview));
  PICK.i = cur >= 0 ? cur : 0;
  G.picking = true;
  $('plaque').hidden = true; $('picker').hidden = false;
  if (!$('cards').children.length) buildCards();
  pickShow();
  cancelAnimationFrame(PICK.raf); PICK.raf = requestAnimationFrame(drawPreviews);
}
function closePicker() {
  G.picking = false; cancelAnimationFrame(PICK.raf);
  $('picker').hidden = true; $('plaque').hidden = false;
}
function pickMove(d) { PICK.i = (PICK.i + d + HEROES.length * 3) % HEROES.length; PICK.tapped = false; pickShow(); }
function pickBegin() {
  const id = HEROES[PICK.i].id, then = PICK.then;
  closePicker();
  if (then) then(id);
}
G.picker = { open: openPicker, move: pickMove, begin: pickBegin, close: closePicker, state: () => ({ open: G.picking, i: PICK.i, id: HEROES[PICK.i].id }) };

// ------------------------------------------------------------------ title screen, buttons, keys
function wire() {
  $('btnLog').onclick = () => setLog(!G.log);
  $('logClose').onclick = () => setLog(false);
  $('btnSave').onclick = () => save(true);
  $('btnSound').onclick = () => { G.audio.start(); const m = G.audio.toggle(); $('btnSound').textContent = m ? 'sound: off' : 'sound: on'; };
  $('btnSound').textContent = G.audio.muted ? 'sound: off' : 'sound: on';
  $('dlg').addEventListener('pointerdown', (e) => { e.preventDefault(); advanceDialogue(); });
  wirePad(); wireOptions(); wireLeveling();
  $('btnBack').onclick = () => closePicker();
  $('btnBegin').onclick = () => pickBegin();
  addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (G.picking || G.title) e.stopImmediatePropagation();   // the engine's own keys (talk on Enter) wait for the field
    if (G.picking) {
      if (k === 'arrowleft' || k === 'a') pickMove(-1); else if (k === 'arrowright' || k === 'd') pickMove(1);
      else if (k === 'arrowup' || k === 'w') pickMove(-3); else if (k === 'arrowdown' || k === 's') pickMove(3);
      else if (k === 'enter' || k === ' ') { e.preventDefault(); pickBegin(); } else if (k === 'escape') closePicker();
      return;
    }
    if (G.title) { if (k === 'enter' || k === ' ') { e.preventDefault(); (readSave() ? cont : newGame)(); } else if (k === 'n') newGame(); return; }
    if (G.asking) { if (k === 'y') askPick(true); else if (k === 'n' || k === 'escape') askPick(false); else if (k.startsWith('arrow') || k === 'a' || k === 'd') askMove(); else if (k === 'enter' || k === ' ') { e.preventDefault(); askPick(ASK.yes); } e.stopImmediatePropagation(); return; }
    if (G.heroUI) { e.stopImmediatePropagation(); heroKey(k, e); return; }
    if (k === 'i') { setHeroUI(true); return; }
    if (k === 'o') { setOpts(!G.opts); return; }
    if (k === 'j' || k === 'l') setLog(!G.log);
    if (k === 'escape') { if (G.opts) setOpts(false); else if (G.dlg) closeDialogue(); else if (G.log) setLog(false); }
    if (k === 'k' || ((e.ctrlKey || e.metaKey) && k === 's')) { e.preventDefault(); save(true); }
    if (k === 'm') { G.audio.start(); const m = G.audio.toggle(); $('btnSound').textContent = m ? 'sound: off' : 'sound: on'; }
  });
  addEventListener('pointerdown', () => G.audio.start(), { once: true });
  addEventListener('keydown', () => G.audio.start(), { once: true });
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') save(); });
  addEventListener('pagehide', () => save());
  $('btnNew').onclick = () => newGame();
  $('btnCont').onclick = () => cont();
}
function closeTitle() { G.title = false; $('titlescreen').hidden = true; document.body.classList.remove('titled'); $('vitals').hidden = false; G.audio.start(); }
function applyHero() {
  const ctx = G.ctx; if (!ctx) return;
  if (ctx.actors.meta.roles[G.S.cls]) ctx.actors.setRole(ctx.player, G.S.cls);
  ctx.setSpellCycle(slots()); ctx.selectSpell(0);
  if (G.S.hp == null) G.S.hp = G.combat.maxHp();
}
async function newGame() {
  if (G.busy || G.picking) return;
  const had = readSave();
  if (had && !confirmNew()) return;
  openPicker((cls) => startNew(cls));
}
async function startNew(cls) {
  G.S = fresh(); G.S.cls = cls; PR.ensure(G.S); G.S.hp = HERO[cls].hp;
  closeTitle();
  if (G.area !== 'plaza') await go('plaza', 'start', 'walk');
  else { const s = G.ctx.scene.game.spawns.start; G.ctx.player.x = s[0]; G.ctx.player.z = s[1]; G.ctx.player.y = G.ctx.heightAt(s[0], s[1]); G.ctx.player.facing = s[2]; G.ctx.clock.set(G.S.t); }
  applyHero();
  drawBag(); drawLog(); refreshMarkers();
  save();
  toast(`Welcome to Hearthmoor, ${HERO[cls].cls}. Marla the baker is waving at you.`, 3.2);
  if (G.S.autoLevel == null && !Q.has('autolevel')) askAuto();
  else if (Q.has('autolevel')) G.S.autoLevel = Q.get('autolevel') !== '0';
}
// replacing a save takes a second press of New game (works with touch, mouse, keys and a controller; no browser dialog)
let newArmed = 0;
function confirmNew() {
  if (Q.has('force') || performance.now() < newArmed) { newArmed = 0; return true; }
  newArmed = performance.now() + 4000;
  const b = $('btnNew'); b.textContent = 'Replace save? Press again'; b.classList.add('warn');
  setTimeout(() => { if (performance.now() >= newArmed) { b.textContent = 'New game'; b.classList.remove('warn'); } }, 4100);
  return false;
}
async function cont() {
  if (G.busy || G.picking) return;
  const s = readSave(); if (!s) return newGame();
  if (!s.cls) {   // a migrated v1 save: choose your hero once, keep everything else
    openPicker((cls) => { s.cls = cls; s.hp = HERO[cls].hp; delete s.migrated; resume(s); });
    return;
  }
  resume(s);
}
async function resume(s) {
  G.S = { ...fresh(), ...s, v: 2 }; PR.ensure(G.S);
  closeTitle();
  G.busy = true;
  $('fade').className = 'on';
  await new Promise((r) => setTimeout(r, 300));
  await loadArea(s.area || 'plaza', 'start', s.pos);
  applyHero();
  save();
  $('fade').className = '';
  G.busy = false;
  toast(`Welcome back. ${G.ctx.scene.name}, ${$('clocktxt').textContent}`, 2.6);
}

// ------------------------------------------------------------------ leveling: XP, level-up glow, auto-level ask, hero screen
G.gainXP = (n, src) => {
  PR.ensure(G.S);
  const up = PR.addXP(G.S, n);
  const ctx = G.ctx, p = ctx && ctx.player;
  if (p && G.combat.ctx === ctx) G.combat.number('+' + Math.round(n) + 'xp', p.x + 0.4, p.y + 2.3, p.z, '#8ec8e8');
  if (up && p) levelUp();
  return up;
};
function levelUp() {
  const ctx = G.ctx, p = ctx.player, C = G.combat;
  G.S.hp = C.maxHp(); C.st = C.maxSt();
  if (ctx.effects) { ctx.effects.spawn('bloom_ring', p.x, p.y, p.z + 0.04); ctx.effects.spawn('sparkle_burst', p.x, p.y, p.z + 0.06); ctx.effects.spawn('light_orb', p.x, p.y + 0.4, p.z + 0.07); }
  if (ctx.burst) for (let i = 0; i < 3; i++) setTimeout(() => ctx.burst('sparkle', p.x, p.y + 1.0, p.z + 0.1), i * 160);
  G.audio.sfx('quest');
  const pts = G.S.autoLevel ? '' : ` ${G.S.free} stat point${G.S.free === 1 ? '' : 's'} to spend (I).`;
  toast(`Level ${G.S.lv}!${pts}${G.S.sp ? ' A skill point is ready.' : ''}`, 3.0);
  $('vitals').classList.add('lvup'); setTimeout(() => $('vitals').classList.remove('lvup'), 1600);
  save();
}
const ASK = { yes: true };
function askAuto() { G.asking = true; ASK.yes = true; $('autolv').hidden = false; syncAsk(); }
function syncAsk() { $('btnAutoYes').classList.toggle('on', ASK.yes); $('btnAutoNo').classList.toggle('on', !ASK.yes); }
function askMove() { ASK.yes = !ASK.yes; syncAsk(); }
function askPick(yes) {
  G.asking = false; $('autolv').hidden = true;
  G.S.autoLevel = !!yes; if (yes) PR.autoSpend(G.S);
  syncAutoBtn(); save();
  toast(yes ? 'Auto level on: stat points follow your class. Change it in options (O).' : 'Manual leveling: spend points on the hero screen (I).', 3.2);
}
function syncAutoBtn() { const b = $('btnAuto'); if (b) b.textContent = 'auto level: ' + (G.S.autoLevel ? 'on' : 'off'); }
const HUI = { tab: 0, i: 0 };
function setHeroUI(open) {
  if (open && (G.title || G.busy || G.dlg || G.picking)) return;
  G.heroUI = open; $('heroui').hidden = !open;
  if (open) { if (G.log) setLog(false); if (G.opts) setOpts(false); PR.ensure(G.S); drawHero(); }
}
G.setHeroUI = setHeroUI;
function drawHero() {
  const S = G.S, C = G.combat, h = HERO[S.cls], M = C.M, tree = PR.TREES[S.cls] || [];
  $('heroHead').innerHTML = `<b>${h.cls}</b> <span class="tag">Lv ${S.lv}</span> <span class="tag">${S.lv >= PR.LEVEL_CAP ? 'max level' : `${S.xp} / ${PR.xpNeed(S.lv)} xp`}</span>`
    + `<span class="tag">HP ${C.maxHp()}</span><span class="tag">ST ${C.maxSt()}</span><span class="tag">crit ${Math.round(M.crit * 100)}%</span>`;
  document.querySelectorAll('#heroTabs button').forEach((b, k) => b.classList.toggle('on', k === HUI.tab));
  const body = $('heroBody');
  if (HUI.tab === 0) {
    HUI.n = PR.STATS.length;
    body.innerHTML = `<p class="pts">${S.free} stat point${S.free === 1 ? '' : 's'} free${S.autoLevel ? ' · auto level is on (class picks)' : ''}</p>`
      + PR.STATS.map((st, k) => `<div class="row${k === HUI.i ? ' sel' : ''}" data-k="${k}"><b>${st.name}</b><em>${S.stats[st.id]}</em><span>${st.does}</span>`
      + `<button class="wbtn sm plus" data-stat="${st.id}" ${S.free ? '' : 'disabled'}>+</button></div>`).join('');
    body.querySelectorAll('[data-stat]').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); if (PR.spendStat(S, b.dataset.stat)) { G.audio.sfx('pickup'); save(); drawHero(); } }; });
  } else {
    HUI.n = tree.length;
    body.innerHTML = `<p class="pts">${S.sp} skill point${S.sp === 1 ? '' : 's'} · tier I of each branch (1 point each)</p>`
      + tree.map((n, k) => `<div class="row node${S.skills[n.id] ? ' got' : ''}${k === HUI.i ? ' sel' : ''}" data-k="${k}"><b>${n.branch}</b><em>${n.name}</em><span>${n.desc}</span>`
      + `<button class="wbtn sm plus" data-node="${n.id}" ${S.skills[n.id] || !S.sp ? 'disabled' : ''}>${S.skills[n.id] ? '✓' : 'learn'}</button></div>`).join('');
    body.querySelectorAll('[data-node]').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); if (PR.learn(S, b.dataset.node)) { G.audio.sfx('quest'); save(); drawHero(); } }; });
  }
  body.querySelectorAll('.row').forEach((r) => { r.onclick = () => { HUI.i = +r.dataset.k; drawHero(); }; });
}
function heroAct() {
  const S = G.S, b = $('heroBody').querySelector(`.row[data-k="${HUI.i}"] button`);
  if (b && !b.disabled) b.click();
}
function heroTab(d) { HUI.tab = (HUI.tab + d + 2) % 2; HUI.i = 0; drawHero(); }
function heroMove(d) { HUI.i = Math.max(0, Math.min((HUI.n || 1) - 1, HUI.i + d)); drawHero(); }
function heroPad(name) {
  if (name === 'b' || name === 'start') setHeroUI(false);
  else if (name === 'lb' || name === 'left') heroTab(-1); else if (name === 'rb' || name === 'right') heroTab(1);
  else if (name === 'up') heroMove(-1); else if (name === 'down') heroMove(1);
  else if (name === 'a' || name === 'x') heroAct();
}
function heroKey(k, e) {
  if (k === 'escape' || k === 'i') setHeroUI(false);
  else if (k === 'arrowleft' || k === 'a' || k === 'q') heroTab(-1); else if (k === 'arrowright' || k === 'd' || k === 'e') heroTab(1);
  else if (k === 'arrowup' || k === 'w') heroMove(-1); else if (k === 'arrowdown' || k === 's') heroMove(1);
  else if (k === 'enter' || k === ' ' || k === 'f') { e.preventDefault(); heroAct(); }
}
function wireLeveling() {
  $('btnAutoYes').onclick = () => askPick(true); $('btnAutoNo').onclick = () => askPick(false);
  $('btnAuto').onclick = () => { G.S.autoLevel = !G.S.autoLevel; if (G.S.autoLevel) PR.autoSpend(G.S); syncAutoBtn(); save(); };
  $('heroClose').onclick = () => setHeroUI(false);
  document.querySelectorAll('#heroTabs button').forEach((b, k) => { b.onclick = () => { HUI.tab = k; HUI.i = 0; drawHero(); }; });
  $('vitals').addEventListener('click', () => setHeroUI(true));
  $('heroui').addEventListener('pointerdown', (e) => { if (e.target === $('heroui')) setHeroUI(false); });
}
G.ask = { open: askAuto, pick: askPick };

// ------------------------------------------------------------------ start
async function main() {
  wire();
  if (Q.has('reset')) localStorage.removeItem(SLOT_V2);
  if (Q.has('pad') || (matchMedia('(pointer: coarse)').matches && !Q.has('nopad') && !QA)) document.body.classList.add('padon');
  const s = readSave();
  if (QA) {
    G.title = false; $('titlescreen').hidden = true; $('vitals').hidden = false;
    G.S.cls = HERO[Q.get('hero')] ? Q.get('hero') : 'wildcaller'; PR.ensure(G.S); G.S.autoLevel = true;
    if (Q.get('state')) Object.assign(G.S, JSON.parse(Q.get('state')));
    await loadArea(Q.get('area') || 'plaza', Q.get('spawn') || 'start');
  } else {
    document.body.classList.add('titled');
    $('btnCont').hidden = !s;
    if (s) $('saveInfo').textContent = `Saved: ${new Date(s.savedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} · ${s.cls ? HERO[s.cls].cls + ' · ' : ''}${Object.values(s.quests).filter((v) => v === 3).length}/3 errands${s.migrated ? ' · (older save: pick your hero to continue)' : ''}`;
    G.preview = (s && s.cls) || 'wildcaller';
    await loadArea('plaza', 'start');    // the plaza idles behind the title card
  }
  if ($('pad')) $('btnPad') && $('btnPad').classList.toggle('on', document.body.classList.contains('padon'));
  G.ready = true;
  if (!QA && 'serviceWorker' in navigator && location.protocol.startsWith('http') && !Q.has('nosw')) navigator.serviceWorker.register('sw.js').catch(() => {});
}
main().catch((e) => { console.error(e); const b = $('boot'); if (b) { b.classList.remove('gone'); b.textContent = 'Hearthmoor failed to load: ' + e.message; } });
